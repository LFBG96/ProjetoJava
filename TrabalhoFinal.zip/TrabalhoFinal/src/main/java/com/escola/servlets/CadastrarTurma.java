package com.escola.servlets;

import java.io.IOException;

import com.escola.dao.TurmaDao;
import com.escola.model.Turma;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/cadastrarTurma")
public class CadastrarTurma extends HttpServlet{
	private TurmaDao turmaDao;
	
	
	public void init() throws ServletException {
		this.turmaDao = new TurmaDao();
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String codigo = request.getParameter("codigo");
		String nome = request.getParameter("nome");
		
		Turma t = new Turma(codigo, nome); 
		turmaDao.save(t);
		
		request.setAttribute("sMensagem", "Cadastrado com Sucesso");
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/formTurma.jsp");
		requestDispatcher.forward(request, response);
	}


}
