package com.escola.servlets;


import java.util.ArrayList;
import java.util.List;

import com.escola.dao.AlunoDao;
import com.escola.model.Aluno;

public class ListarAlunos {
	public List<Aluno> findAll() {
		
		List<Aluno> alunos = new ArrayList<>();
		
		
		return alunos;
	}

}
