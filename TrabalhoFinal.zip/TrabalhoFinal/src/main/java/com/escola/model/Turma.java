package com.escola.model;

public class Turma {
	private int id;
	private String codigo;
	private String nomeT;
	
	public Turma() {
		
	}
	public Turma (String codigo,String nomeT) {
		this.codigo = codigo;
		this.nomeT = nomeT;
	}
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNomeT() {
		return nomeT;
	}
	public void setNomeT(String nomeT) {
		this.nomeT = nomeT;
	}
	@Override
	public String toString() {
		return "Turma [id=" + id + ", codigo=" + codigo + ", nome=" + nomeT + "]";
	}
	


}
