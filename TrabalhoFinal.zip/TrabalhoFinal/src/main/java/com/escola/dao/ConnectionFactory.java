package com.escola.dao;
import java.sql.Connection;
import java.sql.DriverManager;


public class ConnectionFactory {
	public static Connection getConnection() {
		String url = "jdbc:mysql://localhost:3306/escola";
		Connection conn = null;
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, "root", "");
		}catch(Exception e) {
			System.out.println("Erro ao tentar abrir conexão!");
			e.printStackTrace();
		}
		
		return conn;
	}
}
