package com.escola.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.escola.model.Turma;

public class TurmaDao {
	public void save(Turma turma) {
		
		String query = "INSERT INTO turma(codigo,nome) VALUES (?, ?)";
		
		try(Connection conn = ConnectionFactory.getConnection()) {
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, turma.getCodigo());
			ps.setString(2, turma.getNomeT());
			
			ps.execute();
		}catch(SQLException e) {
			System.out.println("Erro ao tentar inserir no banco de dados");
			e.printStackTrace();
		}
	}

	
	public List<Turma> findAll() {
		List<Turma> turmas = new ArrayList<>();
		String query = "SELECT * FROM turma";
		try(Connection conn = ConnectionFactory.getConnection()){
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Turma t = new Turma();
				t.setId(rs.getInt("id"));
				t.setCodigo(rs.getString("codigo"));
				t.setNomeT(rs.getString("nome"));
				
				turmas.add(t);
			}
		}catch(SQLException e) {
			System.out.println("Erro ao tentar buscar do banco de dados");
			e.printStackTrace();
		}
		return turmas;
	}


}
