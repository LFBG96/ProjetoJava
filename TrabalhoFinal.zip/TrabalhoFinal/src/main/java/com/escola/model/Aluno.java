package com.escola.model;

public class Aluno extends Turma{
	private String matricula;
	private String nome;
	private int idTurma;
	
	public Aluno() {}
	
	public Aluno(String matricula,String nome,int idTurma) {
		this.matricula = matricula;
		this.nome = nome;
		this.idTurma = idTurma;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdTurma() {
		return idTurma;
	}

	public void setIdTurma(int idTurma) {
		this.idTurma = idTurma;
	}

	@Override
	public String toString() {
		return "Aluno [matricula=" + matricula + ", nome=" + nome + ", idTurma=" + idTurma + "]";
	}
	
	

}
