package com.escola.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.escola.model.Aluno;
import com.escola.model.Turma;


public class AlunoDao {
	public void save(Aluno aluno) {
		//Declarar a query sql
		String query = "INSERT INTO aluno(matricula,nome,IdTurma) VALUES (?, ?, ?)";
		//Abrir a conexão com banco de dados
		try(Connection conn = ConnectionFactory.getConnection()) {
			//Preparar a query
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, aluno.getMatricula());
			ps.setString(2, aluno.getNome());
			ps.setInt(3, aluno.getIdTurma());
			//INSERT INTO contatos(nome, email) VALUES (João, j@email.com)
			//Executa a query
			ps.execute();
		}catch(SQLException e) {
			System.out.println("Erro ao tentar inserir no banco de dados");
			e.printStackTrace();
		}
	}
	public List<Aluno> findAll() {
		List<Aluno> alunos = new ArrayList<>();
		String query = "SELECT aluno.matricula, aluno.nome, aluno.idTurma,turma.nome FROM aluno JOIN turma on aluno.idTurma = turma.id";
		try(Connection conn = ConnectionFactory.getConnection()){
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Aluno a = new Aluno();
				
				a.setMatricula(rs.getString("aluno.matricula"));
				a.setNome(rs.getString("aluno.nome"));
				a.setIdTurma(rs.getInt("aluno.idTurma"));
				a.setNomeT(rs.getString("turma.nome"));
				
				
				
				alunos.add(a);
			}
		}catch(SQLException e) {
			System.out.println("Erro ao tentar buscar do banco de dados");
			e.printStackTrace();
		}
		return alunos;
	}

}
