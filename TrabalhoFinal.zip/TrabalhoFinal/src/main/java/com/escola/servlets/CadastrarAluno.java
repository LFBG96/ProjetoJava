package com.escola.servlets;

import java.io.IOException;

import com.escola.dao.AlunoDao;

import com.escola.model.Aluno;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/cadastrarAluno")
public class CadastrarAluno extends HttpServlet{
	private AlunoDao alunoDao;
	
	
	public void init() throws ServletException {
		this.alunoDao = new AlunoDao();
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String matricula = request.getParameter("matricula");
		String nome = request.getParameter("nome");
		int idTurma = Integer.parseInt(request.getParameter("idTurma"));
		
		Aluno a = new Aluno(matricula,nome,idTurma); 
		alunoDao.save(a);
		
		request.setAttribute("sMensagem", "Cadastrado com Sucesso");
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/formAluno.jsp");
		requestDispatcher.forward(request, response);
	}



}
